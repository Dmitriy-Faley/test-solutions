import $ from 'jquery';
window.$ = window.jQuery = $;


import './js/main'
import './js/jquery.maskedinput'
import './scss/main.scss'


import 'swiper/swiper.scss';
import 'swiper/swiper.min.css';
import 'swiper/modules/navigation/navigation.scss';
import 'swiper/modules/pagination/pagination.scss';
import 'swiper/modules/scrollbar/scrollbar.scss';
import 'swiper/modules/effect-cube/effect-cube.scss';

import 'swiper/swiper-bundle.js'
import 'swiper/swiper-bundle.esm.js'